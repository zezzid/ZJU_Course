function vout = switch_nl(vin,Ts,CS,VsupplyP,VsupplyN,Size,KPN,KPP,VTN,VTP,BS);
% Non-linear switch resistance (S. Brigati, P. Malcovati)
%
% vout = switch_nl(vin,Ts,CS,VsupplyP,VsupplyN,Size,KPN,KPP,VTN,VTP,BS)
%
% vin:		Input signal amplitude
% Ts:		Sample time in s
% CS:		Sampling capacitance in F
% VsupplyP:	Positive supply voltage (NMOS gate voltage) in V
% VsupplyN:	Negative supply voltage (NMOS gate voltage) in V
% Size:		Common n and p-MOS size (W/L)
% KPN:		n-MOS gain factor (u*Cox) in A/V^2
% KPP:		p-MOS gain factor (u*Cox) in A/V^2
% VTN:		n-MOS threshold voltage in V
% VTP:		p-MOS threshold voltage in V
% BS:		Switch bootstrapping between 0 and 1 (0 no bootstrap, 1 ideal bootstrap)
%
% vout:		Output signal amplitude at the end of the sampling phase

Gswn=KPN*Size*(VsupplyP-VTN-vin+BS*vin);
if (Gswn<0) Gswn=0;
end
Gswp=KPP*Size*(-VsupplyN+vin+VTP-BS*vin);
if (Gswp<0) Gswp=0;
end
Rsw=1/(Gswn+Gswp);
vout=vin*(1-exp(-Ts/(2*Rsw*CS)));