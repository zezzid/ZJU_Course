function blkStruct = slblocks
% Defines the Simulink library block representation for SDtoolbox

%   Author: Andrea Fornasari, Piero Malcovati
%   Copyright 1997-2002 University of Pavia
%   $Revision: 2.0

blkStruct.Name    = ['SD Toolbox'];
blkStruct.OpenFcn = 'SDtoolbox';

blkStruct.MaskDisplay = ['plot([5,0,3,0,5],[20,20,10,0,0],[7,10,13,7],[0,20,0,0]);'];

% Define the library list for the Simulink Library browser.
% Return the name of the library model and the name for it
Browser(1).Library = 'SDtoolbox';
Browser(1).Name    = 'SDtoolbox';
Browser(1).IsFlat  = 0;% Is this library "flat" (i.e. no subsystems)?

blkStruct.Browser = Browser;

% End of slblocks.m
