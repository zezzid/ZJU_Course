function [Ampl,Phases] = Noise_init(Nsin,FN,Fs,fC1,fC2,AmplCorner1,AmplCorner2,RNS,EIV,DPSD,noisein);
% Initializes the colored noise generator (by A. Fornasari, P. Malcovati)
%
% [Ampl,Phases] = Noise_init(Nsin,FN,Fs,fC1,fC2,AmplCorner1,AmplCorner2,RNS,EIV,DPSD,noisein)
%
% Nsin:			Number of sinusoidal spectral components
% FN:			Number of times that the noise power spectral density is folded
% Fs:			Sampling frequency in Hz
% fC1:			Noise first corner frequency in Hz
% fC2:			Noise second corner frequency in Hz
% AmplCorner1:	Noise first corner power in V^2/Hz
% AmplCorner2:	Noise second corner power in V^2/Hz
% RNS:			Random number seed
% EIV:			Noise power spectral density vector (1 true, 0 false)
% DPSD:			Plot the power spectral densities (1 true, 0 false)
% noisein:		Input noise power spectral density vector
%
% Ampl:			Vector containing the powers of the spectral components in V^2
% Phases:		Vector containing the initial phases of the spectral components in rad

N=2*Nsin;
rand('state',RNS);
Phases=2*pi*rand(1,Nsin);

Bbin=[1:N*FN];
f=(Bbin*Fs/N);

if EIV==1
    y=interp1(noisein(:,1),noisein(:,2),f);
else
    [c,k1]=calc_paramA(fC1,AmplCorner1,fC2,AmplCorner2);
    y=(k1./f+c)./(1+f.^2/fC2^2);
end

Area=y(1:N*FN)*Fs/N;

AreaF=reshape(Area,[N,FN])';

if FN>1
    AmplFs=sum(AreaF);
else 
    AmplFs=AreaF;
end

Ampl=AmplFs(1:N/2)+AmplFs(N:-1:N/2+1);
Ampl_norm=Ampl*N/Fs;
Ampl_nof=AreaF(1,:)*N/Fs;

if DPSD==1
figure
clf;

grid on;

hold on
plot( f, 10*log10(y), 'r');
axis([0 (Fs*FN) min(10*log10(y))-6  max(10*log10(y))+6]);
set(gca,'Xscale','log')
set(gcf,'NumberTitle','off'); 
set(gcf,'Name', 'Power Spectral Density' );
legend('Noise PSD before folding')
grid on;

xlabel('\bf Frequency [Hz]')
ylabel('\bf PSD [dB]')

figure

clf
grid on;

hold on
plot(f(1:N/2), 10*log10(Ampl_nof(1:N/2)), 'r');
plot(f(1:N/2), 10*log10(Ampl_norm), 'b');
axis([0 (Fs/2) min(10*log10(Ampl_nof))-6 max(10*log10(Ampl_norm))+6]);
set(gca,'Xscale','log')
set(gcf,'NumberTitle','off'); 
set(gcf,'Name', 'Power Spectral Density between 0-Fs');
legend('Noise PSD before folding','Noise PSD after folding')

xlabel('\bf Frequency [Hz]')
ylabel('\bf PSD [dB]')

grid on;
end