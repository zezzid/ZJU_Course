function com = ADconv(Vin,Vthreshold)
% Implements the ADC (by A. Fornasari, P. Malcovati)
%
% com = ADconv(Vin,Vthreshold)
%
% Vin:			Input signal
% Vthreshold:	Threshold voltage array
%
% com:			Quantized output voltage (decimal representation)

termometric=((Vin-Vthreshold)>0);

com=sum(termometric)+1;