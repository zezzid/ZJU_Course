function out = jitteredSinewave(time,Amplitude,Bias,Freq,Phase,SampJ)
% Generates a sine wave with sampling jitter, the derivative of the signal is
% analytically calculated (by A. Fornasari, P. Malcovati)
%
% out = jitteredSinewave(time,Amplitude,Bias,Freq,Phase,SampJ)
%
% time:			Current time
% Amplitude:	Amplitude of the sinusoid
% Bias:			DC value of the sinusoid
% Freq:			Frequency of the sinusoid in rad/s
% Phase:		Initial phase of the sinusoid in rad
% SampJ:		Stadard deviation of the sampling jitter in s
%
% out:			Jittered sinewave

out=Bias+Amplitude*sin(Freq*time+Phase)+Freq*Amplitude*cos(Freq*time+Phase)*SampJ*randn;