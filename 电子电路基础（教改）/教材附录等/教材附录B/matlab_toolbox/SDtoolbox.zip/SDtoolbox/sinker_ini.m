function  [f,FL,FH] = sinker_ini(Fs,fBL,fBH,Fin,N,SN)
% Initializes the variables for the power spectal density calculation (by A. Fornasari, P. Malcovati)
%
% [f,FL,FH] = sinker_ini(Fs,fBL,fBH,Fin,N,SN)
%
% Fs:			Sampling frequency in Hz
% fBL:			Lower bound of the baseband in Hz
% fBH:			Upper bound of the baseband in Hz
% Fin:			Signal frequency in Hz
% N:			Number of simulation points
% SN:			Identification number of the figure used for plots
%
% f:			Normalized signal frequency (Fin/Fs)
% FL:			Lower bound of the baseband in bins
% FH:			Upper bound of the baseband in bins

f=Fin/Fs;
FL=fBL/Fs*N;
FH=fBH/Fs*N;
clear global vout1;
clear global index;
index =0;