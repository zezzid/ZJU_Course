function [c,k1]=calc_paramA(x1,y1,x2,y2);
% Calculates the parameters for flicker noise
% (by A. Fornasari, P. Malcovati)
%
% [c,k1]=calc_paramA(x1,y1,x2,y2)
%
% x1:		Noise first corner frequency in Hz
% y1:		Noise first corner power in V^2/Hz
% x2:		Noise second corner frequency in Hz
% y2:		Noise second corner power in V^2/Hz
%
% [c,k1]:	Parameters of the flicker noise

c=-(-x1^3*y1-x1*x2^2*y1+2*x2^3*y2)/((x1-x2)*x2^2);


k1=-(x1*(x1^2*y1+x2^2*y1-2*x2^2*y2))/(x1*x2-x2^2);