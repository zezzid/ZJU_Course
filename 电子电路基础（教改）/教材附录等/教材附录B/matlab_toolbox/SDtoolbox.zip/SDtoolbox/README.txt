SD Toolbox Version 2.0

To install add the directory SDtoolbox and all its subdirectories to the MATLAB Path.

Type SDtoolbox to start.