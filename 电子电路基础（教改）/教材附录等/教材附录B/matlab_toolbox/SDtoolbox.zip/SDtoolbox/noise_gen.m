function out = noise_gen(u,Ampl,Phases,Fs,N);
% Generates colored noise spectral components (by A. Fornasari, P. Malcovati)
%
% out = noise_gen(u,Ampl,Phases,Fs,N)
%
% u:			Frequencies of the spectral component in Hz
% Ampl:			Vector containing the powers of the spectral components in V^2
% Phases:		Vector containing the initial phases of the spectral components in rad
% Fs:			Sampling frequency in Hz
% N:			Number of spectral components
%
% out:			Spectral components of the colored noise

spectral_component=(sqrt(2*Ampl).*sin(2*pi*[1:N]*Fs/(2*N)*u+Phases(1:N)));
out=sum(spectral_component);