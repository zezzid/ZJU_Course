function [Vthreshold,ncap,DAClevelIDEAL,DAClevelREAL] = iniADC_DAC(NF,k,MM,LF,CST,VV,match,VVG)
% Determines the ADC thresholds and the DAC levels, the input and output range
% is between -1 and +1 (by A. Fornasari, P. Malcovati)
%
% [Vthreshold,ncap,DAClevelIDEAL,DAClevelREAL] = iniADC_DAC(NF,k,MM,LF,CST,VV,match,VVG)
%
% NF:				LOG file name
% k:				Number of comparators in the ADC
% MM:				Consider capacitor mismatch (1 true, 0 false)
% LF:				Create LOG file (1 true, 0 false)
% CST:				Total DAC capacitance value
% VV:				Rundom number vector
% match:			Matching parameter in sqrt(F)
% VVG:				Random number vector provided (1 true, 0 false)
%
% Vthreshold:		ADC threshold levels
% ncap:				Number of DAC capacitors
% DAClevelIDEAL:	DAC equivalent voltage levels without capacitor mismatch
% DAClevelREAL:		DAC equivalent voltage levels with capacitor mismatch

th=[-1:2/(k+1):1];

Vthreshold=th(2:length(th)-1)*(k+1)/k;
DAClevelID=[-1+1/(k+1):2/(k+1):1-1/(k+1)]*(k+1)/k;

if MM==1
UnitCAP=CST/k;
else
    CST=1e-12;
    UnitCAP=CST/k;
end
    
ncap=k;

if VVG==1
    variance=VV;
else
    variance=randn(1,ncap);
end

sigma=match./sqrt(UnitCAP);
CAPVALUES=(1+MM*variance*sigma)*UnitCAP;
ARRAYCAP=CAPVALUES(1:ncap);
IDARRAYCAP=UnitCAP*(1+0*variance(1:ncap));

DAClevelREAL = DAClevelGEN(ARRAYCAP,ncap,CST);
DAClevelIDEAL = DAClevelGEN(IDARRAYCAP,ncap,CST);

if LF==1
		fid=fopen(NF,'wt');

		fprintf(fid,'\nADC Levels (ideal)\n');
		fprintf(fid,'%g  ',Vthreshold);

		fprintf(fid,'\n DAC Levels (real)\n');
		fprintf(fid,'%g  ',DAClevelREAL);
		fprintf(fid,'\n DAC Levels (ideal)\n');
		fprintf(fid,'%g  ',DAClevelIDEAL);

		fprintf(fid,'\n CAP (real)\n');
		fprintf(fid,'%g  ',ARRAYCAP);
		fprintf(fid,'\n CAP (ideal)\n');
		fprintf(fid,'%g  ',IDARRAYCAP);
	  
		status=fclose(fid);
	end








