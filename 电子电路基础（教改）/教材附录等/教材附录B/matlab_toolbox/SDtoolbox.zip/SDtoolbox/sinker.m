function OUT = sinker(in,f,fBL,fBH,N,Ntransient,index,SN,Fs,VW,savename,Scale_type)
% Calculates the power spectral density (by A. Fornasari, P. Malcovati)
%
% OUT = sinker(in,f,fBL,fBH,N,Ntransient,index,SN,Fs,VW,savename,Scale_type)
%
% in:			Input data stream
% f:			Normalized signal frequency
% fBL:			Lower bound of the baseband in bins
% fBH:			Upper bound of the baseband in bins
% N:			Number of simulation points
% Ntransient:	Number of initial simulation points to be discarded
% index:		Current simulation point
% SN:			Identification number of the figure used for plots
% Fs:			Sampling frequency in Hz
% VW:			Save the data in an output file (1 true, 0 false)
% savename:		Name of the output file for saving the data
% Scale_type:	Selects the scale type for the x-axis (1 linear, 2 logarithmic)
%
% OUT:			Output data stream

global vout1
 

index=index+1;





vout1(index,SN)=in;
if length(vout1)==N+Ntransient+1
vout=vout1(Ntransient+1:Ntransient+N,SN)';  

w=hann_pv(N);
[snrdB,ptotdB,psigdB,pnoisedB] = calcSNR(vout,f,fBL+1,fBH,w,N);
ENOBloc=(snrdB-1.76)/6.02;



figure (SN);
clf;
if Scale_type == 2 

semilogx(linspace(0,Fs/2,N/2), ptotdB(1:N/2), 'b');
text_handle = text(floor(Fs/40),-125, sprintf('SNDR = %4.1f dB \nENOB = %2.2f bits ',snrdB,ENOBloc),'EdgeColor','red','LineWidth',3,'BackgroundColor',[1 1 1],'Margin',10);

else
    
plot(linspace(0,Fs/2,N/2), ptotdB(1:N/2), 'b');
text_handle = text(floor(25*Fs/80),-125, sprintf('SNDR = %4.1f dB \nENOB = %2.2f bits ',snrdB,ENOBloc),'EdgeColor','red','LineWidth',3,'BackgroundColor',[1 1 1],'Margin',10);

end

grid on;
title('Power Spectral Density','Fontweight','bold','Fontsize',13)
xlabel('Frequency [Hz]','Fontweight','bold')
ylabel('PSD [dB]','Fontweight','bold')
axis([0 Fs/2 -160 0]);
set(gcf,'NumberTitle','on'); 
set(gcf,'Name', 'Power Spectral Density');
OUT=vout1(index,SN);

if VW==1

    SNR_dB=snrdB;
    ENOB=ENOBloc;
    PTOT_dB=ptotdB;
    PSIG_dB=psigdB;
    PNOISE_dB=psigdB;
    
    save(savename,'SNR_dB','ENOB','PTOT_dB','PSIG_dB','PNOISE_dB')
end

else
    OUT=vout1(index,SN);
end