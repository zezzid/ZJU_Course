function DAClevelREAL = DAClevelGEN(CAPREAL,ncap,CST)
% Determines the DAC levels (by A. Fornasari, P. Malcovati)
%
% DAClevelREAL = DAClevelGEN(CAPREAL,ncap,CST)
%
% CAPREAL:			Real DAC capacitance value array
% ncap:				Number of DAC capacitors
% CST:				Total DAC capacitance value
%
% DAClevelREAL:		DAC equivalent voltage levels

if rem(ncap+1,2)==0
    ele=1:[(ncap+1)/2];
    pal=2*ele-1;
        for s=1:[(ncap+1)/2]
            DAClevelP(s)=sum(CAPREAL(1:pal(s)));
        end

DAClevelN=-DAClevelP((ncap+1)/2:-1:1);
DAClevelREAL=[DAClevelN,DAClevelP]/CST;

else

    ele=1:[(ncap)/2];
    pal=2*ele;
        for s=1:[(ncap)/2]
            DAClevelP(s)=sum(CAPREAL(1:pal(s)));
        end

DAClevelN=-DAClevelP((ncap)/2:-1:1);
DAClevelREAL=[DAClevelN,0,DAClevelP]/CST;

end