% 2nd Order Low-Pass Sigma-Delta Modulator Model with Colored Noise Source
% by S. Brigati, A. Fornasari, P. Malcovati
% The modulator structure is simulated using Simulink (sd2mod_colored.mdl).
% 1. Plots the Power Spectral Density of the bit-stream 
% 2. Calculates the SNR
% 3. Calculates histograms at the integrator outputs

clear

t0=clock;

% ************************************************************************
% Variabili globali
% ************************************************************************
bw=22.05e3;				% Base-band
R=256;
Fs=R*2*bw;				% Oversampling frequency
Ts=1/Fs;
N=2^14;                 % Samples number
nper=12;
Fin=nper*Fs/N;			% Input signal frequency (Fin = nper*Fs/N)
Ampl=0.5-pi/256;		% Input signal amplitude [V]
Ntransient=0;
load noise_by_eldo.txt; % example of noise output spectral density provided by eldo
%
%
k=1.38e-23;				% Boltzmann Constant
Temp=300;				% Absolute Temperature in Kelvin
Cs=2.5e-12;				% Integrating Capacitance of the first integrator
alfa=(1e3-1)/1e3;		% A=Op-amp finite gain (alfa=(A-1)/A -> ideal op-amp alfa=1)
Amax=1.35;				% Op-amp saturation value [V]
sr=20e6;				% Op-amp slew rate [V/s]
GBW=150e6;				% Op-amp GBW [Hz]
noise1=10e-6;			% 1st int. output noise std. dev. [V/sqrt(Hz)]
delta=4e-9;				% Random Sampling jitter (std. dev.) [s] (Boser, Wooley JSSC Dec. 88)
NCOMPARATORI=15;        % Four bit quantizer
match=9e-10;            % Realistic value, but not related to any technology (because of non disclosure agreement)

% Modulator coefficients

b=0.5;

finrad=Fin*2*pi;		% Input signal frequency in radians


s0=sprintf('** Simulation Parameters **');
s1=sprintf('   Fs(Hz)=%1.0f',Fs);
s2=sprintf('   Ts(s)=%1.6e',Ts);
s3=sprintf('   Fin(Hz)=%1.4f',Fin);
s4=sprintf('   BW(Hz)=%1.0f',bw);
s5=sprintf('   OSR=%1.0f',R);
s6=sprintf('   Npoints=%1.0f',N);
s7=sprintf('   tsim(sec)=%1.3f',N/Fs);
s8=sprintf('   Nperiods=%1.3f',N*Fin/Fs);
disp(s0)
disp(s1)
disp(s2)
disp(s3)
disp(s4)
disp(s5)
disp(s6)
disp(s7)
disp(s8)
% ************************************************************************
% Open Simulink diagram first
% ************************************************************************
open_system('SD2mod_colored')

options=simset('InitialState', zeros(1,3), 'RelTol', 1e-3, 'MaxStep', 1/Fs);
sim('SD2mod_colored', (N+Ntransient)/Fs, options);	% Starts Simulink simulation

% ************************************************************************
% Histograms of the integrator outputs
% ************************************************************************

figure(4)
nbins=200;
[bin1,xx1]=histo(y1, nbins);
[bin2,xx2]=histo(y2, nbins);
clf;
subplot(1,2,1), plot(xx1, bin1)
grid on;
title('First Integrator Output')
xlabel('Voltage [V]')
ylabel('Occurrences')
subplot(1,2,2), plot(xx2, bin2)
grid on;
title('Second Integrator Output')
xlabel('Voltage [V]')
ylabel('Occurrences')
