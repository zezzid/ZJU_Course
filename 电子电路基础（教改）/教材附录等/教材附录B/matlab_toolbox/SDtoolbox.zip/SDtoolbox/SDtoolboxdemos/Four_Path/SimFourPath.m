% 16th Order Band-Pass Sigma-Delta Modulator Model
% by A. Fornasari, P. Malcovati
% The modulator structure is simulated using Simulink (OnePath.mdl).
% 1. Plots the Power Spectral Density of the bit-stream 
% 2. Calculates the SNR

clear

phs=0;
bw=5e6;                 % Signal Bandwidth
R=32;                   % Oversampling ratio
Fs=R*(2*bw);            % Sampling frequency		
Ts=1/Fs;                % Sampling time
N=16384;                % Number of samples
w=hann_pv(N);           % Windowing Function
nper=36;                % Number of periods
fBL=N/4-((N/Fs)*bw/2);
fBH=N/4+((N/Fs)*bw/2);
Fin=nper*Fs/N+Fs/4;     % Input signal frequency (Fin = nper*Fs/N)
Ampl=0.2-pi/1000;       % Input signal amplitude [V]
f=Fin/Fs;	            % Normalized signal frequency
finrad=Fin*2*pi;        % Input signal frequency (rad/s)
Ntransient=2;
Vref=1;
%
% Integrator parameters
%
k=1.38e-23;				% Boltzmann Constant
ctot=1e-12;				% Sampling Capacitance
NCOMPARATORI=8;
match=9e-10;            % Realistic value, but not related to any technology (because of non disclosure agreement)

t0=clock;

B1i=10/7;
B1f=B1i;
B2i=1/2;
B1lf=1/77;
B3i=2;
B4i=1/2;
B4lf=1/14;
B1ff=3;
B2ff=2;
B3ff=1;
B4ff=1;

SetReal;

yy1=zeros(1,N);
Vzero=zeros(1,32);

%**************************************************************************************%
%************************************Open Simulink*************************************%
%**************************************************************************************%
open_system('FourPaths')
options=simset('InitialState', zeros(1,30), 'RelTol', 1e-3, 'MaxStep', 1/Fs);
sim('FourPaths', (N+Ntransient)/Fs, options);

%**************************************************************************************%
%**************Calculates SNR and PSD of the bit-stream and of the signal**************%
%**************************************************************************************%

yy1=yout(2+Ntransient:1+N+Ntransient)';
ptot=zeros(1,N);
[snr,ptot,psigdB,pnoisedB]=calcSNR(yy1(1:N),f,fBL,fBH,w,N); 
Rbit=(snr-1.76)/6.02;

figure(1);
clf;
plot(linspace(0,Fs/2,N/2), ptot(1:N/2), 'r');
grid on;
title('PSD of a 4th-Order 4-path Sigma-Delta Modulator')
xlabel('Frequency [Hz]')
ylabel('PSD [dB]')
axis([0 Fs/2 -160 0]);

figure(2);
clf;
semilogx(linspace(0,Fs/2,N/2), ptot(1:N/2), 'r');
grid on;
title('PSD of a 4th-Order 4-path Sigma-Delta Modulator')
xlabel('Frequency [Hz]')
ylabel('PSD [dB]')
axis([Fs/8 Fs/2 -160 0]);

figure(3);
clf;
plot(linspace(0,Fs/2,N/2), ptot(1:N/2), 'r');
hold on;
title('PSD of a 4th-Order 4-path Sigma-Delta Modulator (detail)')
xlabel('Frequency [Hz]')
ylabel('PSD [dB]')
axis([Fs/4-Fs/R Fs/4+Fs/R -160 0]);
grid on;
hold off;
text_handle = text(floor(Fs/4+1e6),-20, sprintf('SNR = %4.1fdB @ OSR=%d\n',snr,R));
text_handle = text(floor(Fs/4+1e6),-40, sprintf('ENOB = %2.2f bits @ OSR=%d\n',Rbit,R));

s1=sprintf('   SNR(dB)=%1.3f',snr);
s2=sprintf('   Simulation time =%1.3f min',etime(clock,t0)/60);
disp(s1)
disp(s2)