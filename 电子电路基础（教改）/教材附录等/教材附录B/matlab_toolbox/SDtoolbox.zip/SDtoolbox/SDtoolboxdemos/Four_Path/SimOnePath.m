% 4th Order Low-Pass Sigma-Delta Modulator Model
% by A. Fornasari, P. Malcovati
% The modulator structure is simulated using Simulink (OnePath.mdl).
% 1. Plots the Power Spectral Density of the bit-stream 
% 2. Calculates the SNR

clear

bw=2.5e6;			    % Signal Bandwidth
R=32;                   % Oversampling ratio
Fs=80e6;
Ts=1/(4*Fs);            % Sampling time
N=2^14;                 % Number of samples
w=hann_pv(N);           % Windowing Function
nper=97;                % Number of periods
fB=N/Fs*bw/2;
Fin=nper*Fs/N;          % Input signal frequency (Fin = nper*Fs/N)
Ampl=0.5-pi/1000;       % Input signal amplitude [V]
f=Fin/Fs;	            % Normalized signal frequency
finrad=Fin*2*pi;        % Input signal frequency (rad/s)
Ntransient=20;
NCOMPARATORI=8;
match=9e-10;            % Realistic value, but not related to any technology (because of non disclosure agreement)
ctot=1e-12;

%
% Coefficients
%
B1i=10/7;
B1f=B1i;
B2i=1/2;
B1lf=1/77;
B3i=2;
B4i=1/2;
B4lf=1/14;
B1ff=3;
B2ff=2;
B3ff=1;
B4ff=1;
%
% Integrator parameters
%

k=1.38e-23;				% Boltzmann Constant

Temp1=300;
Temp2=300;
Temp3=300;
Temp4=300;
TempF=300;
TempFL1=300;
TempFL2=300;
Cf1=0.7e-12;
Cf2=0.2e-12;
Cf3=0.1e-12;
Cf4=0.2e-12;
alfa1a=(56e3-1)/56e3;
alfa1b=(56e3-1)/56e3;
alfa2a=(56e3-1)/56e3;
alfa2b=(56e3-1)/56e3;
Sat1a=2.8;
Sat1b=2.8;
Sat2a=2.8;
Sat2b=2.8;
SR1a=796.5e6;
SR1b=796.5e6;
SR2a=796.5e6;
SR2b=796.5e6;
GBW1a=549e6;
GBW1b=549e6;
GBW2a=549e6;
GBW2b=549e6;
noise1=150e-6;
noise2=412e-6;
noise3=837e-6;
noise4=459e-6;
ExtraNoise=0;
SourceNoise=0;
delta=0;
Vzero=zeros(1,8);

t0=clock;
fd=1;
yy1=zeros(1,N);

open_system('OnePath')
options=simset('InitialState', zeros(1,7), 'RelTol', 1e-3, 'MaxStep', Ts);
sim('OnePath', (N+Ntransient)/Fs, options);

%**************************************************************************************%
%**************Calculates SNR and PSD of the bit-stream and of the signal**************%
%**************************************************************************************%

yy1=Output(2+Ntransient:1+N+Ntransient)';
ptot=zeros(1,N);
[snr,ptot,psigdB,pnoisedB]=calcSNR(yy1(1:N),f,1,fB,w,N); 
Rbit=(snr-1.76)/6.02;

figure(1);
clf;
plot(linspace(0,Fs/2,N/2), ptot(1:N/2), 'r');
grid on;
title('PSD of a 4th-Order Sigma-Delta Modulator')
xlabel('Frequency [Hz]')
ylabel('PSD [dB]')
axis([0 Fs/2 -180 0]);
% 	hold off;

figure(2);
clf;
semilogx(linspace(0,Fs/2,N/2), ptot(1:N/2), 'r');
% 	hold on;
%  	semilogx(linspace(0,Fs/2,N/2), psig(1:N/2), 'g');
% 	semilogx(linspace(0,Fs/2,N/2), pnoise(1:N/2), 'b');
grid on;
title('PSD of a 4th-Order Sigma-Delta Modulator')
xlabel('Frequency [Hz]')
ylabel('PSD [dB]')
axis([0 Fs/2 -180 0]);
% hold off;

figure(3);
clf;
plot(linspace(0,Fs/2,N/2), ptot(1:N/2), 'r');
hold on;
title('PSD of a 4th-Order Sigma-Delta Modulator (detail)')
xlabel('Frequency [Hz]')
ylabel('PSD [dB]')
axis([0 bw -180 0]);
grid on;
hold off;
text_handle = text(floor(1e6),-20, sprintf('SNR = %4.1f dB @ OSR=%d\n',snr,R));
text_handle = text(floor(1e6),-40, sprintf('ENOB = %2.2f bits @ OSR=%d\n',Rbit,R));

s1=sprintf('   SNR(dB)=%1.3f',snr);
s2=sprintf('   Simulation time =%1.3f min',etime(clock,t0)/60);
disp(s1)
disp(s2)