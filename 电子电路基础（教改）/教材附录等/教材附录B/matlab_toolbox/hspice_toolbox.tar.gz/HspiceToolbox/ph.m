%  written by Mike Perrott 
%   Copyright 1999 by Silicon Laboratories, Inc.

function [y] = ph(x)

y = 180/pi*angle(x);
